from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def aboutUs(request):
    return HttpResponse ("Welcome to about us view")
def index(request):
    data={
        'title':'Career Dreams'
    }
    return render(request,'index.html')
def test(request):
    return render(request,'test.html')
def careers(request):
    return render(request,'careers.html')
def universities(request):
    return render(request,'universities.html')
def careertips(request):
    return render(request,'careertips.html')
def profile(request):
    return render(request,'profile.html')

